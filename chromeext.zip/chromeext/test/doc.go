// Package test is a test for chrome extension.
package test
